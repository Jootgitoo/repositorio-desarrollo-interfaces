﻿namespace GestPro_CarlosCalzado.persistence
{
}

namespace GestPro_CarlosCalzado.persistence
{


    public partial class DataSet1
    {
    }
}
